var config = {};

config.users = {  
   "mohit sharma":{  
      "policies":[  
         {  
            "policyNo":1234,
            "renewalDate":"28-03-2018",
            "premium":"1"
         }
      ]
   },
   "praveen":{  
      "policies":[  
         {  
            "policyNo":1234,
            "renewalDate":"22-07-2018",
            "premium":"1000"
         }
      ]
   },
   "sashi":{  
      "policies":[  
         {  
            "policyNo":1234,
            "renewalDate":"08-06-2018",
            "premium":"4000"
         }
      ]
   }
};

module.exports = config;